---
name: financeiro-comprovantes
description: "Use when handling Igor's financial receipts, boletos, invoices, card bills, payment proofs, monthly controls, and audits under ~/MEGA/Comprovantes."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [financeiro, comprovantes, faturas, boletos, auditoria, brasil]
    related_skills: [ocr-and-documents]
---

# Financeiro: Comprovantes

## Overview

Use esta skill para qualquer tarefa financeira envolvendo boletos, faturas, contas, comprovantes de pagamento, transferências, controles mensais e auditoria da pasta de comprovantes do Igor.

Pasta base autorizada:

`/home/igorferreira/MEGA/Comprovantes`

Perfil recomendado:

`finance-senior`

## When to Use

Use quando o usuário enviar ou mencionar:

- boleto;
- fatura de cartão;
- conta de consumo;
- comprovante de PIX, boleto, cartão, TED, DOC ou transferência;
- necessidade de organizar arquivos financeiros;
- atualização de controle mensal;
- fechamento mensal;
- auditoria de comprovantes;
- pendências abertas ou comprovantes faltantes.

Não use para:

- alterar arquivos fora de `/home/igorferreira/MEGA/Comprovantes` sem autorização explícita;
- apagar documentos financeiros originais em caso de dúvida;
- inferir valores/datas sem evidência no arquivo, OCR ou contexto do usuário.

## Estrutura esperada

A estrutura principal usa ano e mês:

```text
/home/igorferreira/MEGA/Comprovantes/
└── 2026/
    ├── 2026_01_JANEIRO/
    ├── 2026_02_FEVEREIRO/
    ├── ...
    └── _Controle_Anual/
```

Dentro de cada mês, os arquivos principais tendem a seguir:

- `INDEX.md`
- `AAAA-MM_00_CONTROLE_PAGAMENTOS.md`
- `AAAA-MM_CONTAS_FATURAS.md`
- arquivos individuais `.md` por documento/transação;
- arquivos originais `.pdf`, `.jpg`, `.png`, etc.

## Padrão de nomes

Use nomes sem espaços quando criar novos arquivos.

Formato geral:

`AAAA-MM-DD_TIPO-ENTIDADE-DESCRICAO-RVALOR-SUFX.ext`

Exemplos:

- `2026-06-15_PIX_CONDOMINIO-PJBANK-R104177-COMPROVANTE-PAGAMENTO.pdf`
- `2026-06-02_FATURA-CARTAO-NUBANK.md`
- `2026-05-10_BOLETO-COND-FREGUESIA-COMPROVANTE-PAGAMENTO.pdf`

Convenções:

- valores em centavos no nome quando já houver padrão local, por exemplo `R104177` para R$ 1.041,77;
- sufixo `COMPROVANTE-PAGAMENTO` para pagamento confirmado;
- sufixo `COMPROVANTE-TRANSFERENCIA` para transferência;
- sufixo `FATURA`, `BOLETO`, `CONTA`, `DIVIDA` conforme o tipo.

## Metadados mínimos por arquivo `.md`

Todo documento financeiro deve tentar registrar:

- Data do documento;
- Data de pagamento, se houver;
- Tipo: fatura, boleto, conta, comprovante, transferência, dívida;
- Valor;
- Pagador;
- Recebedor/beneficiário;
- Banco/instituição, se aplicável;
- Status: Aberto, Pago, Pendente, Revisar;
- Arquivo original;
- Origem relacionada;
- Comprovante relacionado;
- IDs relevantes: linha digitável, código de barras, autenticação, NSU, ID transação, Pix end-to-end, protocolo.

Quando um dado não estiver disponível, use `Não identificado` ou `A confirmar`; não invente.

## Fluxo: boleto, conta ou fatura recebida

1. Identificar ano e mês de vencimento ou competência.
2. Salvar o arquivo original na pasta mensal correta.
3. Criar `.md` com o mesmo nome base do arquivo original.
4. Extrair texto/OCR quando possível.
5. Preencher metadados mínimos.
6. Atualizar `INDEX.md` do mês, se existir.
7. Atualizar `AAAA-MM_00_CONTROLE_PAGAMENTOS.md` como `Aberto` ou `Pendente`, com link em `Origem`.
8. Se já houver comprovante, relacionar `Comprovante` e marcar `Pago`.

## Fluxo: comprovante de pagamento recebido

1. Identificar data do pagamento e valor.
2. Salvar o original com sufixo `COMPROVANTE-PAGAMENTO` ou `COMPROVANTE-TRANSFERENCIA`.
3. Criar `.md` correspondente com OCR/texto e metadados.
4. Procurar origem relacionada no mês e meses próximos.
5. Atualizar controle mensal:
   - status `Pago`;
   - link `Comprovante`;
   - manter link `Origem` quando existir.
6. Se a origem não for encontrada, registrar como item a revisar.

## Fluxo: fechamento mensal

1. Ler `INDEX.md` do mês, se existir.
2. Ler `AAAA-MM_00_CONTROLE_PAGAMENTOS.md`, se existir.
3. Ler `AAAA-MM_CONTAS_FATURAS.md`, se existir.
4. Rodar script de auditoria, quando disponível.
5. Listar pendências abertas.
6. Listar comprovantes sem origem.
7. Listar documentos sem `.md` correspondente.
8. Gerar resumo com totais e pontos de atenção.
9. Não marcar como concluído se houver pendência sem justificativa.

## Cuidados operacionais

- Não apague originais financeiros em caso de dúvida.
- Para itens suspeitos/duplicados, prefira mover para pasta `REVISAR/` dentro do mês.
- Não registre tokens, senhas ou chaves em Markdown.
- Não invente OCR, IDs, datas ou valores.
- Sempre cite caminhos dos arquivos alterados.
- Quando fizer melhoria em agentes ou fluxo financeiro, registre em `/home/igorferreira/.hermes/docs/CHANGELOG.md`.

## Verificação antes de finalizar

- [ ] O arquivo original foi salvo no mês correto.
- [ ] Existe `.md` correspondente quando aplicável.
- [ ] Metadados mínimos foram preenchidos ou marcados como `A confirmar`.
- [ ] Controle mensal foi atualizado quando necessário.
- [ ] Origem e comprovante foram linkados quando ambos existem.
- [ ] Nenhum arquivo real foi apagado sem autorização explícita.
- [ ] A resposta final cita os caminhos principais alterados.
