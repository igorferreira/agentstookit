---
name: fluxo-caixa-cenarios
description: Gera e mantém a pasta fluxo_caixa/ com cenários de saída (atual, demissão, pedido demissão). Inclui scripts Python para janela ótima, comparativo de 9 cenários, e rescisão dinâmica mensal via cron job. Use sempre que Igor mencionar cenários de saída, demissão, pedido demissão, ou "como fico se for mandado embora".
version: 1.0.0
author: Hermes Agent (13/08/2026)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [fluxo-caixa, rescisao, demissao, janela-otima, cenarios, python]
    related_skills: [atualizar-controles, phd-financas-pessoais, auditoria-consistencia-financeira, financeiro-comprovantes]
---

# Fluxo de Caixa — Cenários de Saída

Skill class-level para gerenciar a pasta `~/MEGA/Comprovantes/fluxo_caixa/` com sub-cenários.

## 📁 Estrutura obrigatória

```
~/MEGA/Comprovantes/fluxo_caixa/
├── cenario_atual/                  # X<n>_atual.{xlsx,md,pdf,csv} — continuar na Noorden
├── cenario_demissao/               # dispensa sem justa causa
│   ├── rescisao_YYYY-MM.{md,json}  # atualizado via cron
│   ├── janela_otima_demissao.{md,json}
├── cenario_pedido_demissao/        # pedido demissão
│   ├── comparativo_cenarios_saida.{md,json,pdf}
├── calculos_auxiliares/            # scripts Python reutilizáveis
│   ├── calcular_rescisao.py
│   ├── calcular_janela_otima.py
│   └── calcular_cenarios_saida.py
├── historico/                      # versões antigas (X19, X20, ...)
└── README.md
```

## 🔢 Scripts canônicos (matemática PhD)

### `calcular_rescisao.py` (cron mensal)

Gera `rescisao_YYYY-MM.md` com base em:
- `ADMISSAO = 22/05/2023`
- `SALARIO_BRUTO_BASE = 13.425,48` (triênio incluso)
- Lei 12.506/2011: aviso prévio = `30 + min(60, ⌊anos⌋ × 3)` dias
- FGTS: `42.715 × (1,003)^n + salario × 0,08 × n − 16.000` (saques aniversário)
- HE: `max(0, 108.720 − 2.174 × meses_pagos)` (SAC)
- INSS 10% (faixa 2) + IRRF 15% com dedução R$ 354,80
- Cenários: pedido demissão (aviso dispensado/descontado) + dispensa sem justa causa

**Output:** JSON com `data_referencia`, `anos_completos`, `aviso_previo_dias`, `fgts_acumulado`, `dispensa_sem_justa_causa.caixa_imediato`, `cartoes_negociacao_total` (R$ 62.744 — 6 cartões, BrasilCard removido em 13/08/2026)

### `calcular_janela_otima.py` (sob demanda)

Calcula quando dispensa cobre TUDO (6 cartões + BrasilCard + HE saldo):
- Projeção mês-a-mês (53 meses, Ago/26 → Dez/30)
- 3 targets:
  - 🟢 Mínimo (R$ 63.391): atinge em Ago/26
  - 🟡 Médio (+ HE saldo): atinge em **Ago/2028** (5a3m)
  - 🔴 Completo (+ 24m vida): atinge em Set/2030 (7a3m)
- **Ago/2028 é a janela ótima** — três alavancas se cruzam:
  - Dissídio anual Ago/28 → +R$ 615 no bruto
  - Aviso prévio 5 anos completos (Mai/28) → +3 dias = +R$ 1.341
  - HE já pago 22 meses → saldo cai para R$ 59.570

### `calcular_cenarios_saida.py` (sob demanda)

9 cenários comparativos: Ago/26, Mai/27, Ago/27, Mai/28, Ago/28, Mai/29, Ago/29, Mai/30, Ago/30
- Para cada data: salário bruto (com dissídio Ago de cada ano), aviso prévio, dispensa + 2 versões de pedido demissão
- Gera `comparativo_cenarios_saida.{md,json,pdf}`
- Planilha XLSX: nova aba `Cenários Saída` (dados + gráfico de barras + 10 funções matemáticas)

## ⏰ Cron jobs ativos

| Job ID | Schedule | Comando | Função |
|---|---|---|---|
| `e247555646ba` | `0 9 1 * *` | `python3.12 ~/MEGA/Comprovantes/fluxo_caixa/calculos_auxiliares/calcular_rescisao.py` | Recalcula rescisão todo dia 1º às 09:00 |

## 📋 Atualização do XLSX principal

Quando gerar/atualizar cenário:
1. **Cenário atual**: copiar `FLUXO-CAIXA-2026-2030.{xlsx,md,pdf,csv}` para `cenario_atual/X<n>_atual.*`
2. **Planilha raiz**: manter em `~/MEGA/Comprovantes/FLUXO-CAIXA-2026-2030.{xlsx,md,pdf,csv}` (canônico)
3. **NOVA aba no XLSX**: `Cenários Saída` (a partir do X23) com:
   - Tabela 9 cenários × 12 colunas
   - Gráfico de barras (caixa dispensa vs pedido)
   - 10 funções matemáticas aplicadas (Courier New font)
   - Recomendações com emojis (🟢🟡🔴)

## ⚠️ Premissas Críticas (atualizadas 13/08/2026)

| Premissa | Valor | Origem |
|---|---|---|
| Admissão | 22/05/2023 | CONTRACHEQUE |
| Salário bruto base | R$ 13.425,48 | jul/26 contracheque |
| Dissídio anual | 4,32% | FEAAC ago/26 |
| VALLO | R$ 4.420/mês (FIRME, nunca atrasa) | Confirmado por Igor |
| Aluguel Diego | R$ 2.000/mês | Informado |
| Custo vida Set+ | R$ 4.421 | ORCAMENTO.md |
| Imprevistos | R$ 1.000/mês | Decisão 13/08/2026 |
| 13º Nov/Dez | R$ 6.950 / R$ 5.400 (2026) | Estimativa 50%/39% |
| 13º 2027+ | +5% (1º ano) ou +10% (anos seguintes) | Estimativa dissídio |
| CDB Inicial | R$ 29.155,70 | App C6, print de 10/08/2026 19:09 |
| CDB yield | 1% a.m. | C6 pós-fixada |
| HE principal | R$ 108.719,73 | CCB 004505 |
| HE início | 10/Out/2026 (1ª parcela completa) | App C6 |
| HE fim | 10/Set/2030 | 50 meses |
| 6 cartões em negociação | R$ 78.659,77 mínimo | ENDIVIDAMENTO.md / X28; custos Digio pendentes |
| CDB atinge R$ 150k | Mar/28 (R$ 155.537,10) | Projeção X28 |
| BrasilCard | R$ 647 — REMOVIDO da negociação | Decisão 13/08/2026 (Igor paga) |
| Seguro-desemprego | NÃO elegível | Confirmado 27/07/2026 |

## 🚨 Pitfalls críticos

### Pitfall 1: `'Nov/27'.endswith('Nov')` retorna False
A string `'Nov/27'` termina com `'27'`, NÃO com `'Nov'`. Para detectar meses em qualquer ano:
```python
# ERRADO
if mes.endswith('Nov') or mes.endswith('Dez'):
# CERTO
if mes.startswith('Nov') or mes.startswith('Dez'):
```

### Pitfall 2: Nunca hardcodar a dívida dos cartões em negociação
A posição muda com novas operações, encargos e acordos. Antes de gerar cada cenário:
1. Ler `~/MEGA/Comprovantes/ENDIVIDAMENTO.md`.
2. Reconciliar cada valor com a ficha do cartão.
3. Usar o total mínimo documentado e separar tarifas/IOF/juros ainda pendentes.
4. No X28 (14/08/2026), a posição mínima dos 6 cartões é **R$ 78.659,77**; o Digio está em pelo menos R$ 3.065,30 após a operação prevista de R$900 para o 99Pay.

### Pitfall 3: CDB inicial deve vir do último saldo real confirmado
Nunca herdar automaticamente o saldo inicial do cenário anterior. Reconciliar `Inputs!CDB_Inicial` com `_saldos/SALDO_C6.md` e o último print/extrato antes do recálculo. No X28, o valor correto é **R$ 29.155,70**; o X27 usava R$ 29.167,14, uma diferença de R$ 11,44.

### Pitfall 4: 13º só inclui 2026 se usar `Decimo_1/Decimo_2`
Para Nov/26 e Dez/26, usar `Decimo_1` (R$ 6.950) e `Decimo_2` (R$ 5.400) hardcoded.
Para Nov/Dez 2027+, usar `Decimo_Anual_Nov × 1.05` (1º ano) ou `× 1.10` (anos seguintes).

### Pitfall 5: VALLO NUNCA entra na rescisão
Igor declarou em 23/07/2026 que VALLO é rendimento disponível MAS **NÃO entra em cálculo rescisório** (incluindo o depósito extra do 13º). Respeitar SEMPRE.

### Pitfall 6: PDF aprovado exige auditoria visual após cada alteração
Recalcular o XLSX no LibreOffice, exportar MD/CSV/JSON e só então gerar o PDF. Renderizar todas as páginas e verificar:
- títulos órfãos;
- tabelas separadas do título ou sem cabeçalho;
- páginas vazias/quase vazias;
- cortes e sobreposições.

Para tabelas longas, dividi-las manualmente com cabeçalho repetido. Colocar a quebra de página **antes da seção inteira**, não depois de uma tabela que possa ser empurrada pelo motor do PDF.

### Pitfall 7: `cenario_atual/` deve conter somente a versão vigente
Mover X anteriores para `fluxo_caixa/historico/X<n>/`. Na raiz, manter cópias byte a byte idênticas do cenário vigente em `FLUXO-CAIXA-2026-2030.{md,xlsx,csv,pdf}`. Evitar cópias paralelas em `_controles/`; manter apenas um ponteiro para os arquivos canônicos.

## 📚 Referências

| Arquivo | Conteúdo |
|---|---|
| `references/calculos_rescisao_formulas.md` | Fórmulas matemáticas detalhadas (Lei 12.506/2011, FGTS, HE SAC, INSS/IRRF) |
| `references/janela_otima_explicacao.md` | Por que Ago/2028 é a janela ótima (3 alavancas) |
| `references/cenarios_saida_9_datas.md` | Tabela com 9 cenários × 3 saídas (dispensa + 2 pedidos) |
| `scripts/calcular_rescisao.py` | Script principal de rescisão dinâmica |
| `scripts/calcular_janela_otima.py` | Script de janela ótima |
| `scripts/calcular_cenarios_saida.py` | Script dos 9 cenários comparativos |

## Versão

- **v1.1** (14/08/2026): reconciliação obrigatória do CDB real, dívida dinâmica via ENDIVIDAMENTO, auditoria visual de PDF e limpeza de `cenario_atual/`
- **v1.0** (13/08/2026): criação inicial consolidando todos os cenários de saída