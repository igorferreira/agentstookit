# Card payment proof workflow

Use this checklist when the user sends a card payment receipt image/PDF and expects the financial archive to be updated.

## What to extract

- payment date and time
- amount paid
- beneficiary / favorecido
- destination bank
- due date shown on the receipt
- payer name
- origin bank / agency / account
- transaction ID / auth / NSU when present
- barcode / linha digitável when present

## What to create

- Save the original file in the month folder
- Create a matching `.md` with structured metadata
- Use a filename that includes the actual paid amount in centavos, e.g. `R163885`
- Link the receipt to the corresponding control/debt item

## What to update

- `AAAA-MM_00_CONTROLE_PAGAMENTOS.md`: mark the item as paid and link the comprovante
- `AAAA-MM_00_DIVIDA.md`: also mark the debt entry as paid when that file tracks the same obligation

## Practical pitfalls

- If the receipt and the control file disagree, trust the receipt and update the ledger to match it
- When editing large monthly markdown files, re-read the current file before patching; partial views can lead to malformed table rows
- After saving, verify the new line is present in both monthly files and that the markdown links resolve
