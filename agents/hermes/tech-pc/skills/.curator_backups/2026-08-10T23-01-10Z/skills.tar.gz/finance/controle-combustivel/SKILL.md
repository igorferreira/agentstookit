---
name: controle-combustivel
description: Gestão de abastecimentos de veículo — registro, cálculo de consumo, histórico de preços e visões mensal/trimestral/semestral/anual.
triggers:
  - prefixo "Rubens" ou "Carro" + abastecimento
  - "abasteci"
  - "quantos km por litro"
  - "preço da gasolina"
  - "gasto com combustível"
---

# Controle de Combustível e Consumo

Mecânico de confiança para gestão de abastecimentos. Registra cada tanque, calcula consumo, mantém histórico de preços e projeções de gasto.

---

## 📁 Estrutura de Arquivos

```
~/MEGA/Documentos/Carros/<MODELO>/
├── controle-consumo-combustivel.md    ← log principal (cada abastecimento = 1 linha)
├── historico-precos-combustivel.md    ← preços + acumulados + visões de período
├── abastecimentos/YYYY/              ← registros detalhados por data
│   └── YYYY-MM-DD_ABASTECIMENTO-<POSTO>-<TIPO>-<LITROS>L.md
└── INDEX.md
```

---

## 🔄 Fluxo de Abastecimento

### Quando Igor diz "abasteci"

1. **Coletar dados:** data, posto, combustível, litros, preço (por litro ou total), odômetro, Trip A
2. **Fechar ciclo anterior:** distância = Trip A (ou odômetro atual − anterior), consumo = km ÷ litros
3. **Calcular:** preço/L se não informado, custo/km do ciclo
4. **Atualizar 3 arquivos:**
   - Registro detalhado em `abastecimentos/YYYY/`
   - Nova linha no `controle-consumo-combustivel.md`
   - Atualizar `historico-precos-combustivel.md` (preços, mensal, trimestral, semestral, anual, acumulados)

### ⚠️ Pitfalls

- **Trip A vs odômetro:** se Trip A não foi zerado no abastecimento anterior, a distância do odômetro é maior que a real. SEMPRE usar Trip A se disponível. Confirmar com Igor.
- **Preço sem recibo:** calcular do total ÷ litros. Anotar como "calculado".
- **Odômetro estimado vs real:** se Igor não confirmar, marcar como "~estimado". Corrigir quando ele mandar foto.

---

## 📊 Visões de Período (obrigatórias no histórico de preços)

| Visão | Atualiza quando |
|---|---|
| 📅 **Mensal** | Cada abastecimento — litros e gasto do mês |
| 📆 **Trimestral** | Virada de trimestre (mar, jun, set, dez) |
| 📅 **Semestral** | Virada de semestre (jun, dez) |
| 📆 **Anual** | Virada de ano — com média mensal |

---

## 📋 Modelo de Registro Detalhado

```markdown
# Abastecimento <POSTO> <COMBUSTÍVEL> — <VEÍCULO>

## Identificação
| Campo | Valor |
|---|---|
| Data | DD/MM/AAAA |
| Odômetro | XXXX km |
| Trip A | XXX km |
| Combustível | Tipo |
| Litros | XX,00 L |
| Preço/L | R$ X,XX |
| Total | R$ XXX,XX |

## Fechamento do ciclo anterior
- Distância: XXX km
- Consumo: XX,XX km/L
- Custo: R$ X,XX/km

## Novo ciclo
- Iniciado no odômetro XXXX km com XX L
- ✅ Trip A zerado / ⚠️ Zerar Trip A
```

---

## 📋 Modelo de Linha no Controle

```
| Data | KM odômetro | Litros | Combustível | Valor (R$) | KM rodados | Consumo (km/l) | R$/km |
```

---

## 🎯 Referências de Consumo (Punto 1.4 8V)

| Combustível | Cidade | Estrada |
|---|---|---|
| Gasolina | 9,5–11 km/L | 12–14 km/L |
| Etanol | 6,5–7,5 km/L | 8,5–10 km/L |

Abaixo disso: verificar pneus, filtro de ar, velas, bicos, ar-condicionado.

---

## 🚨 Alertas

- Consumo cidade < 8 km/L → investigar
- Consumo estrada < 11 km/L → investigar
- Preço variou > 5% entre abastecimentos do mesmo posto → destacar
- Trip A NÃO zerado → cobrar na próxima
