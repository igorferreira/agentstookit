---
name: audio-transcription
description: "Use for literal or edited transcription of voice messages, meetings, interviews, and forwarded audio; preserve originals, resolve uncertain terms with multi-pass STT, and deliver verified Markdown/PDF artifacts."
version: 1.0.0
created_by: agent
metadata:
  hermes:
    tags: [audio, transcription, speech-to-text, whatsapp, telegram, whisper, markdown, pdf]
---

# Audio Transcription

## Trigger

Use this skill when the user sends or references an audio/voice message and asks to:

- transcribe literally or produce a cleaned transcript;
- preserve timestamps, speakers, pauses, hesitations, or inaudible markers;
- extract names, legal/technical terms, dates, values, tasks, or decisions;
- save the original audio and transcription;
- generate Markdown and PDF versions.

Do not treat creative music generation or spectrogram work as transcription; route those to `audio-and-music-workflows`.

## User-specific defaults

For Igor:

- store transcription artifacts under `/home/igorferreira/MEGA/Documentos/Transcricoes/`, normally grouped by year;
- preserve the original audio beside the Markdown/PDF;
- default to a **literal revised transcript**: retain oral phrasing, repetitions, pauses, and slang while adding punctuation and correcting only unmistakable recognition errors;
- when Igor asks only for transcription, show it for review before saving; when he explicitly asks to generate/save Markdown or PDF, create the artifacts immediately;
- distinguish the person who forwarded/sent the file from the person speaking; never infer speaker identity from the Telegram/WhatsApp sender label alone.

## Workflow

### 1. Discover and preserve the source

1. Use the explicit attachment path when present.
2. If the gateway gives only an auto-transcript, locate the corresponding recent audio in the Hermes audio cache and verify duration/mtime.
3. Copy the original into the destination before processing.
4. Verify the copy by size and checksum; never replace the original with a converted derivative.
5. Record source platform, receipt timestamp, duration, codec, and speaker identity status.

### 2. Define the transcription mode

- **Literal:** preserve exact wording, repetitions, incomplete constructions, fillers, slang, and relevant non-speech events.
- **Literal revised (Igor default):** same fidelity, with punctuation and correction of unequivocal STT mistakes; disclose every inferred word.
- **Cleaned:** improve grammar and remove repetitions only when explicitly requested.
- **Summary/minutes:** produce after the transcript, not instead of it, unless the user says otherwise.

### 3. Never trust one STT pass for consequential audio

The gateway transcript is a hypothesis, not evidence. For names, legal issues, money, health, allegations, or technical terminology:

1. run the configured/default STT pass;
2. rerun with forced language and a stronger model;
3. use short segments and timestamps when wording remains uncertain;
4. add a narrowly factual context prompt containing likely domain terms, without scripting full sentences that could bias the model;
5. compare passes and word confidence;
6. mark unresolved wording as `[inaudível]`, `[termo incerto: ...]`, or `[palavra provável?]` rather than inventing.

Recommended local escalation:

- quick pass: Whisper `base`;
- improved pass: `small`, forced language, beam search, timestamps;
- consequential/final pass: `large-v3-turbo`, forced language, word timestamps, domain vocabulary.

See [`references/literal-transcription-workflow.md`](references/literal-transcription-workflow.md) for commands and comparison details.

### 4. Editorial rules

- Add punctuation for readability but do not silently rewrite content.
- Preserve unusual but confidently heard wording and flag it in a notes section.
- Normalize an obvious legal/technical recognition error only when multiple cues support it; disclose the normalization.
- Do not convert allegations in audio into factual claims.
- Do not infer a named speaker from voice gender, chat sender, filename, or forwarding metadata.
- If speakers cannot be distinguished reliably, use `Pessoa não identificada` instead of fabricated labels.
- Use timestamps at meaningful paragraph/speaker boundaries; dense word-level timestamps are for the technical sidecar, not the reader-facing transcript.

### 5. Markdown artifact

Use [`templates/transcricao-literal.md`](templates/transcricao-literal.md) as the starting structure.

Minimum sections:

1. title;
2. identification/metadata table;
3. fidelity note;
4. timestamped transcript;
5. uncertain passages requiring human confirmation;
6. content disclaimer for unverified allegations when applicable;
7. transcription method and model passes.

Use descriptive filenames:

`YYYY-MM-DD_AUDIO-COMPARTILHADO-POR-<NOME>-<ASSUNTO>-TRANSCRICAO.md`

Store the original with the same stem minus `-TRANSCRICAO`.

### 6. PDF generation and visual QA

Markdown is the canonical source. Generate PDF only after Markdown is final.

PDF requirements:

- A4, explicit white background, dark readable text, and sufficient margins;
- use `pagetitle` rather than Pandoc `title` when the Markdown already has an H1, to avoid duplicate titles;
- keep metadata tables intact;
- keep headings with following content;
- do not leave a section heading at the bottom of one page with its list/text on the next;
- rebalance pages if a final page is mostly empty by moving a meaningful transcript continuation to it, not by shrinking text excessively;
- verify all pages visually after every pagination change;
- extract PDF text to check missing terms and replacement characters.

A successful PDF check confirms:

- no dark-mode background leakage;
- no duplicate title;
- no orphan heading;
- no split table or isolated list item;
- no blank/almost-empty page when content can be balanced;
- no clipping, overlap, or broken Unicode.

### 7. Delivery

Deliver the requested artifacts with absolute paths and native attachments:

- Markdown;
- PDF when requested;
- original audio only when requested or useful.

Summarize uncertain timestamps so the user can listen and correct them. If the user confirms a word, update both Markdown and PDF and rerun PDF QA.

## Verification checklist

- [ ] Original audio copied and checksum/size verified
- [ ] Duration and source metadata recorded
- [ ] Sender and speaker identity kept separate
- [ ] Consequential terms checked with more than one STT pass
- [ ] Uncertain words visibly marked
- [ ] No allegation presented as verified fact
- [ ] Markdown saved as canonical source
- [ ] PDF text extraction passed
- [ ] Every PDF page visually inspected
- [ ] Markdown/PDF paths delivered

## Pitfalls

- **Using only the gateway transcript:** short legal names and money amounts are often wrong; rerun on the original.
- **Over-correcting literal speech:** punctuation is allowed, paraphrase is not.
- **Prompt contamination:** context prompts should list domain vocabulary, not dictate the expected sentence.
- **Sender = speaker assumption:** forwarded WhatsApp audio can be voiced by someone else.
- **Unreviewed PDF:** correct text can still produce dark backgrounds, duplicate headings, orphan titles, or poorly balanced pages.
