# Cartão com saldo zero confirmado

Use este procedimento quando o usuário enviar uma captura de aplicativo mostrando `R$ 0,00` em aberto e informar que não há fatura nem parcelamentos pendentes.

## 1. Separar fontes de evidência

Registre explicitamente o que cada fonte prova:

- **Imagem/OCR:** valor em aberto, vencimento exibido, limite disponível, bloqueio, final do cartão e demais campos visíveis.
- **Declaração do titular:** ausência de parcelamentos, ausência de compras futuras, cancelamento ou qualquer informação que não apareça na tela.

Nunca escreva que a imagem comprova ausência de parcelamentos se ela mostra apenas o saldo atual.

## 2. Classificação no inventário

Use quatro categorias distintas na auditoria mensal:

1. fatura completa/agregada localizada;
2. obrigação parcial/provisionada;
3. **saldo zero confirmado**;
4. nenhuma informação localizada.

Regras:

- “Fatura não localizada” nunca equivale a saldo zero.
- Uma captura explícita de `R$ 0,00`, apoiada pela confirmação do titular sobre parcelamentos, permite mover o cartão da categoria “sem informação” para “saldo zero confirmado”.
- Não aumente a contagem de faturas completas apenas porque há uma tela de saldo zero.
- Garanta que as categorias somem exatamente o número total de contas/produtos inventariados.

## 3. Arquivos a criar

Na pasta mensal, preservar:

- imagem original;
- OCR bruto `.ocr.txt`;
- Markdown canônico;
- PDF da imagem;
- PDF pesquisável derivado do Markdown quando o relatório financeiro precisar de versão PDF auditável.

No Markdown, incluir:

- valor em aberto;
- vencimento exibido;
- limite disponível;
- status operacional;
- origem de cada informação;
- declaração do titular;
- regra de reabertura do controle se surgir compra, tarifa, anuidade, estorno ou parcelamento.

## 4. Cascata de atualização

Atualizar, quando existirem:

- `AAAA-MM_00_DIVIDA.md`: nota de saldo zero, sem inserir obrigação positiva;
- `AAAA-MM_00_CONTROLE_PAGAMENTOS.md`: linha de R$ 0,00 com status `Sem fatura / sem parcelamentos` e comprovante `Não necessário`;
- `INDEX.md` mensal;
- diagnóstico mensal;
- inventário anual;
- resumo anual.

O total financeiro deve permanecer inalterado. Recalcule para comprovar.

## 5. Status operacional não é dívida

- Cartão bloqueado, desbloqueado, cancelado ou inativo é condição operacional.
- Não transforme bloqueio em dívida nem em prova de quitação.
- Registre o status separadamente do saldo.

## 6. Auditoria final

1. Recalcular o total do mês e confirmar que o item de R$ 0,00 não o alterou.
2. Confirmar que o cartão foi removido da lista “sem informação”.
3. Conferir que as categorias do inventário fecham no total de cartões.
4. Validar todos os links relativos.
5. Extrair texto do PDF pesquisável e procurar valor, vencimento, limite e status.
6. Renderizar todas as páginas dos PDFs e verificar títulos órfãos, tabelas divididas, itens isolados e páginas quase vazias.
7. Se uma quebra manual criar uma página quase vazia, compacte a seção anterior ou reposicione a quebra; reinspecione o documento inteiro.
