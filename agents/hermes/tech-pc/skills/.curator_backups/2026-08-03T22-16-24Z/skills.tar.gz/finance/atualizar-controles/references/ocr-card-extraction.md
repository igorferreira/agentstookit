# OCR de Extrato de Cartão — Workflow

## Quando usar
Quando Igor envia print de fatura/extrato de cartão e pede para extrair os parcelamentos.

## Comando base

```bash
python3 << 'PYEOF'
from PIL import Image, ImageEnhance
import subprocess

img_path = '/home/igorferreira/.hermes/image_cache/<NOME_DA_IMAGEM>.jpg'
img = Image.open(img_path)

# Enhance: contrast 2.5x, sharpen 2.5x, grayscale, 3x resize, threshold
enhancer = ImageEnhance.Contrast(img)
img = enhancer.enhance(2.5)
enhancer = ImageEnhance.Sharpness(img)
img = enhancer.enhance(2.5)
img = img.convert('L')
img = img.resize((img.width*3, img.height*3), Image.LANCZOS)
img = img.point(lambda x: 0 if x < 128 else 255, '1')
img.save('/tmp/<prefix>_ocr_prep.png')

# Try multiple PSM modes
for psm in [3, 4, 6]:
    result = subprocess.run(
        ['tesseract', '/tmp/<prefix>_ocr_prep.png', 'stdout', '-l', 'por', '--psm', str(psm)],
        capture_output=True, text=True
    )
    print(f"=== PSM {psm} ===")
    print(result.stdout)

PYEOF
```

## O que extrair do OCR

### Identificar parcelamentos
Procurar por padrões como:
- `Parcela X de Y` → parcelamento ativo
- `X/Y parcelas` → mesma coisa
- `2 de 2`, `3 de 3` → última parcela (quitando)

### Classificar
- `X/Y` onde X < Y → **parcelamento ativo** (faltam Y−X parcelas)
- `X/Y` onde X = Y → **quitado** (última cobrada neste extrato)
- Sem indicação de parcela → **à vista** (não projeta)

### Calcular o que falta
```
Falta pagar = (Total de parcelas − Parcela atual) × Valor da parcela
Última parcela = mês atual + (Total de parcelas − Parcela atual) meses
```

### Verificar consistência
- Somar todas as parcelas projetadas para o mês seguinte
- Comparar com o valor que o Igor informou (ele geralmente já sabe o total)
- Se bater (diferença < R$ 5), está correto

## Armadilhas comuns

1. **PSM modes diferentes capturam partes diferentes** — sempre rodar PSM 3, 4 e 6
2. **Valores com vírgula** — OCR frequentemente omite a vírgula: `R$119,79` vira `R$11979` ou `R$ 11979`
3. **Nomes de estabelecimentos truncados** — ok, o importante é valor e parcela
4. **Cartão virtual vs físico** — aparecem em seções separadas no extrato Porto
5. **Google/99Pay** — são transações à vista no virtual, não parcelamentos
