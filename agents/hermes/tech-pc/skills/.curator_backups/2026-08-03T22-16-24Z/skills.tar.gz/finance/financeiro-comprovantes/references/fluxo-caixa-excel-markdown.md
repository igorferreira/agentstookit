# Fluxo de Caixa — Excel + Markdown com Python

## Quando usar

Quando o usuário pedir projeção de fluxo de caixa de longo prazo (12+ meses) com:
- Renda variável (dissídios, 13º)
- Parcelamentos de cartão decrescentes
- Empréstimo SAC
- Gastos mensais recorrentes nos cartões
- Geração de planilha Excel + relatório Markdown

## Estrutura do modelo

### Dados de entrada

```python
# Renda base
clt_base = 9306.24      # CLT líquido jul/2026
vallo_base = 4424.92    # VALLO BENEFÍCIOS
monthly_income_base = clt_base + vallo_base

# Gastos mensais nos cartões (aparecem na fatura do mês seguinte)
new_spending = fixas_sem_light_gas + livres + light + gas
# Exemplo: 2597.34 + 2000 + 778 + 140 = 5515.34

# C6 empréstimo SAC
c6_start = 4389.00      # 1ª parcela
c6_amort = 88.00        # redução mensal

# Reserva inicial
reserve_start = 21131.00

# Parcelamentos conhecidos por cartão (dict mês→valor)
card_data = {
    "Nubank": {"2026-09": 5160.86, "2026-10": 4861.53, ...},
    "Passaí": {"2026-09": 961.62, ...},
    ...
}
```

### Função de renda com dissídio e 13º

```python
def get_income(year, month):
    # Dissídio ~4% ao ano, efeito em novembro
    if (year == 2026 and month >= 11) or year >= 2027:
        if year == 2026 or (year == 2027 and month < 11):
            mult = 1.04
        elif (year == 2027 and month >= 11) or (year == 2028 and month < 11):
            mult = 1.04 * 1.04
        else:
            mult = 1.04 * 1.04 * 1.04
    else:
        mult = 1.0

    clt = round(clt_base * mult, 2)
    vallo = round(vallo_base * mult, 2)

    # 13º salário
    extra = 0
    if month == 11:
        gross = 13835.98 * mult
        extra = round(gross * 0.50, 2)
    elif month == 12:
        gross = 13835.98 * mult
        extra = round(gross * 0.39, 2)

    return round(clt + vallo, 2), extra
```

### Montagem do fluxo mensal

Para cada mês de Ago/2026 a Dez/2028:

```python
income, extra = get_income(year, month)
install = installments_by_month.get(key, 0)         # parcelamentos fixos
prev_spending = 0 if key == "2026-08" else new_spending  # gastos do mês anterior
card_bills = round(install + prev_spending, 2)       # total faturas
c6 = round(max(0, c6_start - c6_amort * months_since_sep), 2)  # empréstimo
total_income = round(income + extra, 2)
net = round(total_income - card_bills - c6, 2)
reserve = round(opening + net, 2)
```

### Geração do Excel (openpyxl)

Criar 4 abas:
1. **Fluxo de Caixa** — tabela mensal com: Mês, Reserva Inicial, Renda, Parcelamentos, Novos Gastos, Total Faturas, C6, Saldo Líquido, Reserva Final, Evento
2. **Resumo** — cartões mantidos, negociação, métricas
3. **Parcelamentos** — matriz por cartão
4. **Premissas** — todas as premissas do modelo

Estilização com `PatternFill` para cabeçalhos, linhas alternadas e eventos (dissídio/13º).

### Geração do Markdown

Mesma estrutura de dados, formatada como tabela Markdown com:
- Colunas compactas: Mês | Abertura | Renda | Parcel. | +Gastos | =Faturas | C6 | Saldo | Reserva | Evento
- Seções de resumo por ano, métricas e marcos importantes
- Emojis 🟢🔴 para saldo positivo/negativo

## Pitfalls

- **openpyxl no sandbox**: `execute_code` usa ambiente isolado sem openpyxl. Rodar script Python via `terminal` heredoc (`python3.12 << 'PYEOF'`) onde o pacote está instalado.
- **Parcelamentos invisíveis**: faturas atuais não mostram parcelamentos futuros — solicitar prints do gráfico de "próximas faturas" de cada app.
- **Novos gastos aparecem no mês seguinte**: o gasto de agosto aparece na fatura de setembro.
- **Mês de início**: Ago/2026 não tem gasto do mês anterior porque a fatura de agosto é paga com recursos do CDB (Cenário X2).
